public class Monster extends Creature {
    public Monster(String name, int attack, int defense, int health) {
        super(name, attack, defense, health);
    }
}
